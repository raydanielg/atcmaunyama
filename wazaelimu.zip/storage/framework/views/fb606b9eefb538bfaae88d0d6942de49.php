<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-4">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-xl font-semibold text-gray-900">User Details</h1>
                <p class="text-sm text-gray-500 mt-1">View user profile and manage actions.</p>
            </div>
            <a href="<?php echo e(route('users.index')); ?>" class="inline-flex items-center px-3 py-1.5 rounded border text-gray-700 border-gray-300 hover:bg-gray-100 text-xs">Back to list</a>
        </div>

        <?php if(session('status')): ?>
            <div class="mt-4 p-3 rounded bg-green-50 text-green-700 border border-green-200"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <div class="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
                <h2 class="text-sm font-semibold text-gray-800 mb-3">Profile</h2>
                <dl class="divide-y divide-gray-100">
                    <div class="py-2 grid grid-cols-3 gap-2">
                        <dt class="text-xs text-gray-500">ID</dt>
                        <dd class="col-span-2 text-sm text-gray-900"><?php echo e($user->id); ?></dd>
                    </div>
                    <div class="py-2 grid grid-cols-3 gap-2">
                        <dt class="text-xs text-gray-500">Name</dt>
                        <dd class="col-span-2 text-sm text-gray-900"><?php echo e($user->name); ?></dd>
                    </div>
                    <div class="py-2 grid grid-cols-3 gap-2">
                        <dt class="text-xs text-gray-500">Email</dt>
                        <dd class="col-span-2 text-sm text-gray-900"><?php echo e($user->email); ?></dd>
                    </div>
                    <div class="py-2 grid grid-cols-3 gap-2">
                        <dt class="text-xs text-gray-500">Role</dt>
                        <dd class="col-span-2 text-sm text-gray-900"><?php echo e($user->role); ?></dd>
                    </div>
                    <div class="py-2 grid grid-cols-3 gap-2">
                        <dt class="text-xs text-gray-500">Status</dt>
                        <dd class="col-span-2 text-sm">
                            <?php if($user->banned_at): ?>
                                <span class="inline-flex items-center px-2 py-1 rounded bg-red-50 text-red-700 border border-red-200 text-xs">Banned (<?php echo e($user->banned_at); ?>)</span>
                            <?php else: ?>
                                <span class="inline-flex items-center px-2 py-1 rounded bg-green-50 text-green-700 border border-green-200 text-xs">Active</span>
                            <?php endif; ?>
                        </dd>
                    </div>
                    <div class="py-2 grid grid-cols-3 gap-2">
                        <dt class="text-xs text-gray-500">Created</dt>
                        <dd class="col-span-2 text-sm text-gray-900"><?php echo e($user->created_at); ?></dd>
                    </div>
                </dl>
            </div>

            <div class="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
                <h2 class="text-sm font-semibold text-gray-800 mb-3">Actions</h2>
                <div class="flex flex-wrap gap-2">
                    <?php if($user->banned_at): ?>
                        <form action="<?php echo e(route('users.unban', $user)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="inline-flex items-center px-3 py-2 rounded border text-indigo-700 border-indigo-300 hover:bg-indigo-50 text-xs" onclick="return confirm('Unban this user?')">Unban</button>
                        </form>
                    <?php else: ?>
                        <form action="<?php echo e(route('users.ban', $user)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="inline-flex items-center px-3 py-2 rounded border text-amber-700 border-amber-300 hover:bg-amber-50 text-xs" onclick="return confirm('Ban this user?')">Ban</button>
                        </form>
                    <?php endif; ?>
                    <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="inline-flex items-center px-3 py-2 rounded border text-red-700 border-red-300 hover:bg-red-50 text-xs" onclick="return confirm('Delete this user? This cannot be undone.')">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\NOVO\Desktop\wazaelimuadminpanelofapp\wazaelimu\resources\views/admin/users/show.blade.php ENDPATH**/ ?>