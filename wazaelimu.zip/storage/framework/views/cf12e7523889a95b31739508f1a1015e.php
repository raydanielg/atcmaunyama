<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="p-4">
        <div class="mb-4">
            <h1 class="text-2xl font-bold text-gray-900">My Profile</h1>
            <p class="text-sm text-gray-500">Update your personal information and view feedbacks received.</p>
        </div>

        <?php if(session('status')): ?>
            <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'success','message' => ''.e(session('status')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success','message' => ''.e(session('status')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'error','message' => ''.e($errors->first()).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'error','message' => ''.e($errors->first()).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 items-start">
            <!-- Profile form -->
            <div class="lg:col-span-1 bg-white border rounded-lg p-4">
                <h2 class="font-semibold text-gray-900">Profile Information</h2>
                <p class="text-xs text-gray-500 mb-3">Name, phone number, and region.</p>

                <form action="<?php echo e(route('admin.profile.update')); ?>" method="post" class="space-y-3">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label class="block text-sm text-gray-700">Full Name</label>
                        <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" required />
                    </div>
                    <div>
                        <label class="block text-sm text-gray-700">Phone</label>
                        <input type="text" name="phone" value="<?php echo e(old('phone', $user->phone)); ?>" class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" placeholder="07xx xxx xxx" />
                    </div>
                    <div>
                        <label class="block text-sm text-gray-700">Region</label>
                        <select name="region_id" class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                            <option value="">-- Select Region --</option>
                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($region->id); ?>" <?php echo e((string)old('region_id', $user->region_id) === (string)$region->id ? 'selected' : ''); ?>><?php echo e($region->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="pt-2">
                        <button class="px-4 py-2 bg-gray-900 text-white rounded-md hover:bg-black">Save Changes</button>
                    </div>
                </form>
            </div>

            <!-- Feedbacks received -->
            <div class="lg:col-span-2 bg-white border rounded-lg p-4">
                <div class="flex items-center justify-between">
                    <h2 class="font-semibold text-gray-900">Feedbacks Received</h2>
                    <span class="text-xs text-gray-500">Total: <?php echo e($feedbacks->total()); ?></span>
                </div>

                <?php if($feedbacks->count() === 0): ?>
                    <div class="text-center py-10 text-gray-500">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" class="w-12 h-12 mx-auto mb-2 text-gray-400"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M7.5 8.25h9m-9 3h6.75M21 12c0 4.97-4.03 9-9 9a8.97 8.97 0 01-4.867-1.409L3 21l1.409-4.133A8.97 8.97 0 013 12c0-4.97 4.03-9 9-9s9 4.03 9 9z"/></svg>
                        <div class="text-sm">No feedbacks yet.</div>
                    </div>
                <?php else: ?>
                    <div class="mt-3 overflow-x-auto">
                        <table class="min-w-full text-sm">
                            <thead>
                                <tr class="text-left text-gray-500 border-b">
                                    <th class="py-2 pr-3">From</th>
                                    <th class="py-2 pr-3">Subject</th>
                                    <th class="py-2 pr-3">Message</th>
                                    <th class="py-2 pr-3">Rating</th>
                                    <th class="py-2 pr-3">Status</th>
                                    <th class="py-2 pr-3">Date</th>
                                </tr>
                            </thead>
                            <tbody class="align-top">
                                <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="border-b">
                                        <td class="py-2 pr-3 text-gray-800"><?php echo e($fb->sender?->name ?? 'Anonymous'); ?></td>
                                        <td class="py-2 pr-3 text-gray-800"><?php echo e($fb->subject ?? '—'); ?></td>
                                        <td class="py-2 pr-3 text-gray-600 max-w-[360px]"><?php echo e(Str::limit($fb->message, 120)); ?></td>
                                        <td class="py-2 pr-3"><?php echo e($fb->rating ? $fb->rating.'/5' : '—'); ?></td>
                                        <td class="py-2 pr-3">
                                            <span class="px-2 py-1 rounded text-xs <?php echo e($fb->status==='new' ? 'bg-indigo-50 text-indigo-700' : ($fb->status==='read' ? 'bg-emerald-50 text-emerald-700' : 'bg-gray-100 text-gray-700')); ?>"><?php echo e(ucfirst($fb->status)); ?></span>
                                        </td>
                                        <td class="py-2 pr-3 text-gray-500"><?php echo e($fb->created_at->format('Y-m-d H:i')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-3"><?php echo e($feedbacks->links()); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\NOVO\Desktop\wazaelimuadminpanelofapp\wazaelimu\resources\views/admin/profile/index.blade.php ENDPATH**/ ?>