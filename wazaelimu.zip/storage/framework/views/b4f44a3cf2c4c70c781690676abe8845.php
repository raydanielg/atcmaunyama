<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-xl mx-auto text-center py-10">
        <h1 class="text-2xl font-semibold">Karibu WazaElimu!</h1>
        <p class="text-gray-600 mt-2">Umesajiliwa/Kuingia kwa mafanikio. Tutakuunganisha na App ya simu sasa.</p>

        <div class="mt-6 p-4 bg-white/60 rounded border">
            <p class="text-gray-700">Kusubiri... <span id="seconds" class="font-semibold">5</span>s</p>
            <p class="mt-1 text-sm text-gray-500">Kama app haifunguki, tutakupeleka Play Store.</p>
        </div>

        <div class="mt-6">
            <a href="<?php echo e($playStoreUrl); ?>" class="text-indigo-600 underline" id="fallbackLink">Nenda Play Store sasa</a>
        </div>
    </div>

    <script>
        (function() {
            const secondsEl = document.getElementById('seconds');
            const fallbackLink = document.getElementById('fallbackLink');
            const playStoreUrl = <?php echo json_encode($playStoreUrl, 15, 512) ?>;
            const pkg = <?php echo json_encode($androidPackage, 15, 512) ?>;
            const scheme = <?php echo json_encode($deeplinkScheme || 'app', 15, 512) ?>;
            let seconds = <?php echo e($redirectSeconds ?? 5); ?>;

            function isAndroid() {
                return /Android/i.test(navigator.userAgent);
            }

            function tryOpenApp() {
                if (isAndroid()) {
                    // Try intent first (modern Android)
                    const intentUrl = `intent://open#Intent;scheme=${scheme};package=${pkg};end`;
                    const t = setTimeout(function() {
                        window.location.href = playStoreUrl;
                    }, 1500);
                    window.location.href = intentUrl;
                } else {
                    // Non-Android: just show fallback
                    window.location.href = playStoreUrl;
                }
            }

            const timer = setInterval(() => {
                seconds -= 1;
                secondsEl.textContent = seconds;
                if (seconds <= 0) {
                    clearInterval(timer);
                    tryOpenApp();
                }
            }, 1000);
        })();
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\Users\NOVO\Desktop\wazaelimuadminpanelofapp\wazaelimu\resources\views/auth/welcome.blade.php ENDPATH**/ ?>