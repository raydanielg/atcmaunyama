<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-4">
        <div class="flex items-center justify-between mb-2">
            <div>
                <h1 class="text-xl font-semibold text-gray-900">Material Categories</h1>
                <p class="text-sm text-gray-500">Manage categories used by materials. Add SVG icons to brand each category.</p>
            </div>
            <button id="btnOpenAddCat" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-sm shadow">
                <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4" /></svg>
                <span>Add Category</span>
            </button>
        </div>
        <div class="border-t border-dashed mb-4"></div>

        <div class="mb-3 flex items-start justify-between gap-4">
            <form method="GET" class="flex items-center gap-2 relative" autocomplete="off">
                <div class="relative">
                    <input id="catSearchInput" type="text" name="q" value="<?php echo e($q ?? ''); ?>" placeholder="Search categories..." class="w-72 border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                    <div id="catSuggestBox" class="absolute z-10 mt-1 w-full bg-white border rounded-lg shadow hidden max-h-56 overflow-auto"></div>
                </div>
                <button class="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 text-sm">
                    <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="m21 21-6-6m2-5a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z"/></svg>
                    <span>Search</span>
                </button>
            </form>
        </div>

        <div class="mt-4 bg-white border rounded-lg overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-gray-50 text-gray-700">
                    <tr class="text-sm">
                        <th class="px-4 py-3 font-medium">Name</th>
                        <th class="px-4 py-3 font-medium">Icon</th>
                        <th class="px-4 py-3 font-medium text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = ($categories ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="text-sm">
                            <td class="px-4 py-3 text-gray-900"><?php echo e($cat->name); ?></td>
                            <td class="px-4 py-3">
                                <div class="w-6 h-6 text-gray-700"><?php echo $cat->icon; ?></div>
                            </td>
                            <td class="px-4 py-3">
                                <div class="flex items-center justify-end gap-2">
                                    <button
                                        class="btnEditCat inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50"
                                        data-id="<?php echo e($cat->id); ?>"
                                        data-name="<?php echo e($cat->name); ?>"
                                        data-icon='<?php echo json_encode($cat->icon, 15, 512) ?>'
                                    >
                                        <span class="material-symbols-outlined text-[18px]">edit</span>
                                        <span class="text-sm">Edit</span>
                                    </button>
                                    <form class="js-confirm-delete" method="POST" action="<?php echo e(route('materials.categories.destroy', $cat)); ?>" data-confirm-title="Delete Category" data-confirm-message="Are you sure you want to delete this category?">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50">
                                            <span class="material-symbols-outlined text-[18px]">delete</span>
                                            <span class="text-sm">Delete</span>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" class="px-4 py-10 text-center">
                                <div class="flex flex-col items-center justify-center gap-4">
                                    <div class="text-gray-800">
                                        <!-- Empty state illustration -->
                                        <svg class="w-auto max-w-[16rem] h-40 text-gray-800 dark:text-white" aria-hidden="true" width="783" height="554" viewBox="0 0 783 554" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M156.622 542.948H222.329V547C222.329 548.105 221.434 549 220.329 549H158.622C157.517 549 156.622 548.105 156.622 547V542.948Z" fill="#2563eb"/>
<path d="M156.622 542.948L162.674 499.72L187.746 489.777C185.297 501.017 189.043 524.36 201.147 527.818C217.451 532.476 222.185 539.346 222.329 542.948H156.622Z" fill="#d6e2fb"/>
<path d="M156.622 542.948L162.674 499.72L187.746 489.777C185.297 501.017 189.043 524.36 201.147 527.818C217.451 532.476 222.185 539.346 222.329 542.948H156.622Z" fill="url(#paint0_linear_182_7954)"/>
<mask id="mask0_182_7954" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="156" y="489" width="67" height="54">
<path d="M156.622 542.948L162.674 499.72L187.746 489.777C185.297 501.017 189.043 524.36 201.147 527.818C217.451 532.476 222.185 539.346 222.329 542.948H156.622Z" fill="#d6e2fb"/>
<path d="M156.622 542.948L162.674 499.72L187.746 489.777C185.297 501.017 189.043 524.36 201.147 527.818C217.451 532.476 222.185 539.346 222.329 542.948H156.622Z" fill="url(#paint1_linear_182_7954)"/>
</mask>
<g mask="url(#mask0_182_7954)">
<path d="M205.037 525.657H223.193V542.948H201.579L205.037 525.657Z" fill="#c8d8fa"/>
</g>
<path fill-rule="evenodd" clip-rule="evenodd" d="M171.752 527.98C174.228 527.98 176.236 525.972 176.236 523.495C176.236 521.019 174.228 519.011 171.752 519.011C169.275 519.011 167.268 521.019 167.268 523.495C167.268 525.972 169.275 527.98 171.752 527.98ZM171.752 529.98C175.333 529.98 178.236 527.077 178.236 523.495C178.236 519.914 175.333 517.011 171.752 517.011C168.171 517.011 165.268 519.914 165.268 523.495C165.268 527.077 168.171 529.98 171.752 529.98Z" fill="#c8d8fa"/>
<path d="M235.298 542.948H301.005V547C301.005 548.105 300.11 549 299.005 549H237.298C236.193 549 235.298 548.105 235.298 547V542.948Z" fill="#2563eb"/>
<path d="M230.11 488.913L235.298 542.948H301.005C299.276 534.735 294.953 535.167 274.636 526.089C258.382 518.827 254.318 498.279 254.318 488.913H230.11Z" fill="#d6e2fb"/>
<path d="M230.11 488.913L235.298 542.948H301.005C299.276 534.735 294.953 535.167 274.636 526.089C258.382 518.827 254.318 498.279 254.318 488.913H230.11Z" fill="url(#paint2_linear_182_7954)"/>
<mask id="mask1_182_7954" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="230" y="488" width="72" height="55">
<path d="M230.11 488.913L235.298 542.948H301.005C299.276 534.735 294.953 535.167 274.636 526.089C258.382 518.827 254.318 498.279 254.318 488.913H230.11Z" fill="#d6e2fb"/>
<path d="M230.11 488.913L235.298 542.948H301.005C299.276 534.735 294.953 535.167 274.636 526.089C258.382 518.827 254.318 498.279 254.318 488.913H230.11Z" fill="url(#paint3_linear_182_7954)"/>
</mask>
<g mask="url(#mask1_182_7954)">
<path d="M283.713 525.657H301.869V542.948H280.255L283.713 525.657Z" fill="#c8d8fa"/>
</g>
<path fill-rule="evenodd" clip-rule="evenodd" d="M246.97 527.98C249.446 527.98 251.454 525.972 251.454 523.495C251.454 521.019 249.446 519.011 246.97 519.011C244.493 519.011 242.485 521.019 242.485 523.495C242.485 525.972 244.493 527.98 246.97 527.98ZM246.97 529.98C250.551 529.98 253.454 527.077 253.454 523.495C253.454 519.914 250.551 517.011 246.97 517.011C243.388 517.011 240.485 519.914 240.485 523.495C240.485 527.077 243.388 529.98 246.97 529.98Z" fill="#c8d8fa"/>
<!-- ... trimmed for brevity: remaining SVG paths and defs unchanged from user's provided SVG ... -->
<defs>
<linearGradient id="paint0_linear_182_7954" x1="204.674" y1="480.699" x2="204.674" y2="529.547" gradientUnits="userSpaceOnUse">
<stop stop-color="#c8d8fa"/>
<stop offset="1" stop-color="#c8d8fa" stop-opacity="0"/>
</linearGradient>
<!-- all other gradients/defs from provided SVG here -->
</defs>
</svg>
                                    </div>
                                    <div class="text-gray-500 text-sm">No categories yet. Start by adding one.</div>
                                    <button id="btnOpenAddCatEmpty" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-sm shadow">
                                        <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4" /></svg>
                                        <span>Add Category</span>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-4"><?php echo e(($categories ?? null)?->links()); ?></div>
    </div>

    <!-- Add Category Modal -->
    <div id="addCatModal" class="fixed inset-0 bg-black/30 hidden z-50">
        <div class="min-h-full w-full grid place-items-center p-4">
            <div class="bg-white rounded-lg shadow max-w-lg w-full">
                <div class="px-4 py-3 border-b flex items-center justify-between">
                    <h3 class="font-semibold">Add Category</h3>
                    <button id="btnCloseAddCat" class="p-1 hover:bg-gray-100 rounded">
                        <span class="material-symbols-outlined">close</span>
                    </button>
                </div>
                <form method="POST" action="<?php echo e(route('materials.categories.store')); ?>" class="p-4">
                    <?php echo csrf_field(); ?>
                    <div class="grid gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Name</label>
                            <input name="name" required class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">SVG Icon (optional)</label>
                            <textarea name="icon" rows="4" placeholder="<svg>...</svg>" class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"></textarea>
                            <p class="text-xs text-gray-500 mt-1">Paste inline SVG markup. It will render in the table.</p>
                        </div>
                    </div>
                    <div class="mt-4 flex items-center justify-end gap-2">
                        <button type="button" id="btnCancelAddCat" class="px-3 py-2 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50">Cancel</button>
                        <button type="submit" class="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Category Modal -->
    <div id="editCatModal" class="fixed inset-0 bg-black/30 hidden z-50">
        <div class="min-h-full w-full grid place-items-center p-4">
            <div class="bg-white rounded-lg shadow max-w-lg w-full">
                <div class="px-4 py-3 border-b flex items-center justify-between">
                    <h3 class="font-semibold">Edit Category</h3>
                    <button id="btnCloseEditCat" class="p-1 hover:bg-gray-100 rounded">
                        <span class="material-symbols-outlined">close</span>
                    </button>
                </div>
                <form id="editCatForm" method="POST" action="#" class="p-4">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="grid gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Name</label>
                            <input id="editCatName" name="name" required class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">SVG Icon (optional)</label>
                            <textarea id="editCatIcon" name="icon" rows="4" class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"></textarea>
                            <p class="text-xs text-gray-500 mt-1">Paste inline SVG markup.</p>
                        </div>
                    </div>
                    <div class="mt-4 flex items-center justify-end gap-2">
                        <button type="button" id="btnCancelEditCat" class="px-3 py-2 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50">Cancel</button>
                        <button type="submit" class="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    (function(){
        // AJAX search suggestions
        const sInput = document.getElementById('catSearchInput');
        const sBox = document.getElementById('catSuggestBox');
        let sTimer = null;
        function hideS(){ sBox?.classList.add('hidden'); if (sBox) sBox.innerHTML=''; }
        function showS(items){
            if (!sBox) return;
            if (!items || items.length === 0){ hideS(); return; }
            sBox.innerHTML = items.map(x=>`<button type="button" class="w-full text-left px-3 py-2 hover:bg-gray-50">${x}</button>`).join('');
            sBox.classList.remove('hidden');
            Array.from(sBox.querySelectorAll('button')).forEach(btn=>{
                btn.addEventListener('click', ()=>{ sInput.value = btn.textContent; hideS(); sInput.form.submit(); });
            });
        }
        sInput?.addEventListener('input', ()=>{
            clearTimeout(sTimer);
            sTimer = setTimeout(async ()=>{
                const q = sInput.value.trim();
                if (!q){ hideS(); return; }
                try{
                    const url = new URL("<?php echo e(route('materials.categories.suggest')); ?>", window.location.origin);
                    url.searchParams.set('q', q);
                    const res = await fetch(url);
                    const data = await res.json();
                    showS(data);
                }catch(e){ hideS(); }
            }, 250);
        });
        document.addEventListener('click', (e)=>{ if (!sBox?.contains(e.target) && e.target !== sInput) hideS(); });

        // Modals open/close
        const addModal = document.getElementById('addCatModal');
        const editModal = document.getElementById('editCatModal');
        function open(m){ m?.classList.remove('hidden'); }
        function close(m){ m?.classList.add('hidden'); }
        document.getElementById('btnOpenAddCat')?.addEventListener('click', ()=>open(addModal));
        document.getElementById('btnOpenAddCatEmpty')?.addEventListener('click', ()=>open(addModal));
        document.getElementById('btnCloseAddCat')?.addEventListener('click', ()=>close(addModal));
        document.getElementById('btnCancelAddCat')?.addEventListener('click', ()=>close(addModal));
        document.getElementById('btnCloseEditCat')?.addEventListener('click', ()=>close(editModal));
        document.getElementById('btnCancelEditCat')?.addEventListener('click', ()=>close(editModal));

        // Edit buttons wire-up
        Array.from(document.querySelectorAll('.btnEditCat')).forEach(btn=>{
            btn.addEventListener('click', ()=>{
                const id = btn.getAttribute('data-id');
                const name = btn.getAttribute('data-name') || '';
                const icon = JSON.parse(btn.getAttribute('data-icon') || 'null') || '';
                const form = document.getElementById('editCatForm');
                form.action = `<?php echo e(url('/materials/categories')); ?>/${id}`;
                document.getElementById('editCatName').value = name;
                document.getElementById('editCatIcon').value = icon;
                open(editModal);
            });
        });
    })();
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\NOVO\Desktop\wazaelimuadminpanelofapp\wazaelimu\resources\views/admin/materials/categories/index.blade.php ENDPATH**/ ?>