<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-4">
        <div class="flex items-center justify-between">
            <div class="w-full">
                <h1 class="text-xl font-semibold text-gray-900">Mobile Notifications</h1>
                <p class="text-sm text-gray-500">Send push notifications to app users and manage app updates.</p>
                <!-- Decorative dashed characters line -->
                <div class="mt-2 font-mono text-[11px] tracking-widest text-gray-400 select-none whitespace-nowrap overflow-hidden" aria-hidden="true">
                    - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                </div>
            </div>
        </div>
        <div class="border-t border-dashed mt-2 mb-4"></div>

        <?php if(session('status')): ?>
            <div class="mb-4">
                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success']); ?><?php echo e(session('status')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="mb-4">
                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'error']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'error']); ?>
                    <ul class="list-disc pl-4 space-y-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <!-- Compose Notification -->
            <div class="lg:col-span-2 bg-white border rounded-lg p-4">
                <h3 class="font-semibold text-gray-900">Compose Notification</h3>
                <p class="text-sm text-gray-500 mb-3">Add a title and message, optionally schedule date/time, and choose a repeat.</p>
                <form method="POST" action="<?php echo e(route('mobile.notifications.send')); ?>" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <?php echo csrf_field(); ?>
                    <div class="space-y-3">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Title</label>
                            <input name="title" required maxlength="120" class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Message</label>
                            <textarea name="message" rows="6" required maxlength="1000" class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" placeholder="Your notification message..."></textarea>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Deep Link (optional)</label>
                            <input name="deep_link" maxlength="255" placeholder="app://route or https://..." class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                        </div>
                    </div>
                    <div class="space-y-3">
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Date (schedule)</label>
                                <input type="date" name="schedule_date" class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Time (schedule)</label>
                                <input type="time" name="schedule_time" class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Repeat</label>
                            <select name="repeat" class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                                <option value="none">None</option>
                                <option value="hourly">Hourly</option>
                                <option value="daily">Daily</option>
                                <option value="weekly">Weekly</option>
                                <option value="monthly">Monthly</option>
                            </select>
                        </div>
                        <div class="pt-1 flex items-center gap-2">
                            <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white">
                                <span class="material-symbols-outlined text-[18px]">send</span>
                                Send Notification
                            </button>
                        </div>
                        <p class="text-xs text-gray-500">If you set a schedule, the notification will be sent at the specified time.</p>
                    </div>
                </form>
            </div>

            <!-- Update App Card -->
            <div class="bg-white border rounded-lg p-4">
                <h3 class="font-semibold text-gray-900">Update App</h3>
                <p class="text-sm text-gray-500">Use "Update App" to signal mobile clients to check for updates based on your policy.</p>
                <form method="POST" action="<?php echo e(route('mobile.notifications.update_app')); ?>" class="mt-3">
                    <?php echo csrf_field(); ?>
                    <button class="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white">
                        <span class="material-symbols-outlined text-[18px]">system_update</span>
                        Update App
                    </button>
                </form>
                <div class="mt-3 text-xs text-gray-500">Current time: <?php echo e(($now ?? now())->format('Y-m-d H:i')); ?></div>
            </div>
        </div>

        <!-- Previous Notifications -->
        <div class="mt-6 bg-white border rounded-lg">
            <div class="px-4 py-3 border-b flex items-center justify-between">
                <h3 class="font-semibold text-gray-900">Previous Notifications</h3>
                <div class="text-sm text-gray-500">Reports: clicks/open rate coming soon.</div>
            </div>
            <?php if(($notifications ?? collect())->isEmpty()): ?>
                <div class="p-8 text-center">
                    <div class="flex flex-col items-center gap-4">
                        <!-- Empty state SVG provided by user -->
                        <div class="text-gray-800">
                            <svg class="w-auto max-w-[16rem] h-40 text-gray-800 dark:text-white" aria-hidden="true" width="588" height="574" viewBox="0 0 588 574" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M200 40C200 17.9086 217.909 0 240 0H408C430.091 0 448 17.9086 448 40V481C448 503.091 430.091 521 408 521H240C217.909 521 200 503.091 200 481V40Z" fill="#d6e2fb"/>
<path d="M200 40C200 17.9086 217.909 0 240 0H408C430.091 0 448 17.9086 448 40V481C448 503.091 430.091 521 408 521H240C217.909 521 200 503.091 200 481V40Z" fill="url(#paint0_linear_182_7956)"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M408 10H240C223.431 10 210 23.4315 210 40V481C210 497.569 223.431 511 240 511H408C424.569 511 438 497.569 438 481V40C438 23.4315 424.569 10 408 10ZM240 0C217.909 0 200 17.9086 200 40V481C200 503.091 217.909 521 240 521H408C430.091 521 448 503.091 448 481V40C448 17.9086 430.091 0 408 0H240Z" fill="#c8d8fa"/>
<path d="M293 27C293 23.134 296.134 20 300 20H349C352.866 20 356 23.134 356 27C356 30.866 352.866 34 349 34H300C296.134 34 293 30.866 293 27Z" fill="#2563eb" fill-opacity="0.2"/>
<path d="M242 80C242 74.4772 246.477 70 252 70H400C405.523 70 410 74.4772 410 80V159C410 164.523 405.523 169 400 169H252C246.477 169 242 164.523 242 159V80Z" fill="#F9FAFB"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M410 85H242V83H410V85Z" fill="#c8d8fa"/>
<path d="M263 125.5C263 123.567 264.567 122 266.5 122H287.5C289.433 122 291 123.567 291 125.5C291 127.433 289.433 129 287.5 129H266.5C264.567 129 263 127.433 263 125.5Z" fill="#d6e2fb"/>
<path d="M296 125.5C296 123.567 297.567 122 299.5 122H320.5C322.433 122 324 123.567 324 125.5C324 127.433 322.433 129 320.5 129H299.5C297.567 129 296 127.433 296 125.5Z" fill="#d6e2fb"/>
<path d="M329 125.5C329 123.567 330.567 122 332.5 122H353.5C355.433 122 357 123.567 357 125.5C357 127.433 355.433 129 353.5 129H332.5C330.567 129 329 127.433 329 125.5Z" fill="#d6e2fb"/>
<path d="M362 125.5C362 123.567 363.567 122 365.5 122H386.5C388.433 122 390 123.567 390 125.5C390 127.433 388.433 129 386.5 129H365.5C363.567 129 362 127.433 362 125.5Z" fill="#d6e2fb"/>
<mask id="mask0_182_7956" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="360" y="141" width="30" height="18">
<path fill-rule="evenodd" clip-rule="evenodd" d="M375 157.124C377.202 155.478 378.621 152.899 378.621 150C378.621 147.101 377.202 144.522 375 142.876C376.573 141.7 378.547 141 380.69 141C385.832 141 390 145.029 390 150C390 154.971 385.832 159 380.69 159C378.547 159 376.573 158.3 375 157.124ZM375 157.124C373.427 158.3 371.453 159 369.31 159C364.168 159 360 154.971 360 150C360 145.029 364.168 141 369.31 141C371.453 141 373.427 141.7 375 142.876C372.798 144.522 371.379 147.101 371.379 150C371.379 152.899 372.798 155.478 375 157.124Z" fill="#c8d8fa"/>
</mask>
<g mask="url(#mask0_182_7956)">
<path d="M355 141H375V166H355V141Z" fill="#d6e2fb"/>
</g>
<path fill-rule="evenodd" clip-rule="evenodd" d="M375 157.124C377.202 155.478 378.621 152.899 378.621 150C378.621 147.101 377.202 144.522 375 142.876C376.573 141.7 378.547 141 380.69 141C385.832 141 390 145.029 390 150C390 154.971 385.832 159 380.69 159C378.547 159 376.573 158.3 375 157.124ZM375 157.124C373.427 158.3 371.453 159 369.31 159C364.168 159 360 154.971 360 150C360 145.029 364.168 141 369.31 141C371.453 141 373.427 141.7 375 142.876C372.798 144.522 371.379 147.101 371.379 150C371.379 152.899 372.798 155.478 375 157.124Z" fill="#c8d8fa"/>
<path d="M177 527C177 523.686 179.686 521 183 521H465C468.314 521 471 523.686 471 527V568C471 571.314 468.314 574 465 574H183C179.686 574 177 571.314 177 568V527Z" fill="#d6e2fb"/>
<path d="M177 527C177 523.686 179.686 521 183 521H465C468.314 521 471 523.686 471 527V568C471 571.314 468.314 574 465 574H183C179.686 574 177 571.314 177 568V527Z" fill="url(#paint1_linear_182_7956)"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M526.263 351.891C526.263 354.233 526.689 356.476 527.469 358.546C528.117 360.268 527.673 362.285 526.267 363.472C519.905 368.844 515.864 376.88 515.864 385.859C515.864 389.037 516.37 392.096 517.306 394.961C517.792 396.448 517.383 398.105 516.22 399.152C507.489 407.019 502 418.415 502 431.093C502 454.83 521.243 474.074 544.98 474.074C568.718 474.074 587.961 454.83 587.961 431.093C587.961 418.533 582.574 407.232 573.984 399.373C572.83 398.317 572.433 396.657 572.931 395.174C573.911 392.248 574.443 389.116 574.443 385.859C574.443 376.88 570.402 368.844 564.04 363.472C562.634 362.285 562.19 360.268 562.838 358.546C563.618 356.476 564.044 354.233 564.044 351.891C564.044 341.458 555.587 333 545.154 333C534.721 333 526.263 341.458 526.263 351.891Z" fill="#d6e2fb"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M545.327 350.717C544.775 350.717 544.327 351.165 544.327 351.717L544.327 517.747C544.327 518.3 544.775 518.747 545.327 518.747C545.879 518.747 546.327 518.3 546.327 517.747L546.327 351.717C546.327 351.165 545.879 350.717 545.327 350.717Z" fill="#9ab7f6"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M525.681 425.774C525.232 426.095 525.128 426.719 525.449 427.169L544.513 453.858C544.834 454.308 545.458 454.412 545.908 454.091C546.357 453.77 546.461 453.145 546.14 452.696L527.076 426.006C526.755 425.557 526.131 425.453 525.681 425.774Z" fill="#9ab7f6"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M564.972 384.526C565.421 384.847 565.525 385.471 565.204 385.921L546.14 412.61C545.819 413.06 545.195 413.164 544.745 412.843C544.296 412.522 544.192 411.897 544.513 411.448L563.577 384.758C563.898 384.309 564.523 384.205 564.972 384.526Z" fill="#9ab7f6"/>
<path d="M572.271 493.839C572.321 492.701 571.412 491.751 570.273 491.751H520.034C518.895 491.751 517.986 492.701 518.036 493.839L521.326 568.868C521.373 569.937 522.254 570.78 523.324 570.78H566.983C568.053 570.78 568.934 569.937 568.981 568.868L572.271 493.839Z" fill="#d6e2fb"/>
<path d="M572.271 493.839C572.321 492.701 571.412 491.751 570.273 491.751H520.034C518.895 491.751 517.986 492.701 518.036 493.839L521.326 568.868C521.373 569.937 522.254 570.78 523.324 570.78H566.983C568.053 570.78 568.934 569.937 568.981 568.868L572.271 493.839Z" fill="url(#paint2_linear_182_7956)"/>
<path d="M255 318.5C255 277.907 287.907 245 328.5 245C369.093 245 402 277.907 402 318.5C402 359.093 369.093 392 328.5 392C287.907 392 255 359.093 255 318.5Z" fill="#F9FAFB"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M354.1 297.077C356.266 298.789 356.635 301.933 354.923 304.1L327.915 338.288C325.272 341.633 320.278 341.859 317.344 338.767L302.373 322.987C300.472 320.984 300.555 317.819 302.559 315.918C304.562 314.018 307.727 314.101 309.627 316.104L322.215 329.372L347.077 297.901C348.788 295.734 351.933 295.365 354.1 297.077Z" fill="#0E9F6E"/>
<path d="M8 530.5L0 568H59C59 559 39.6454 556.233 34.5 548C32 544 31.6667 535 32 530.5H8Z" fill="#1F2A37"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M12.5 555C14.433 555 16 553.433 16 551.5C16 549.567 14.433 548 12.5 548C10.567 548 9 549.567 9 551.5C9 553.433 10.567 555 12.5 555ZM12.5 557C15.5376 557 18 554.538 18 551.5C18 548.462 15.5376 546 12.5 546C9.46243 546 7 548.462 7 551.5C7 554.538 9.46243 557 12.5 557Z" fill="#6B7280"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M42.5584 554.527L41.6505 555.435C38.0873 558.998 33.2546 561 28.2155 561H1.49307L1.06641 563H28.2155C33.785 563 39.1264 560.788 43.0647 556.849L44.4 555.514C43.7787 555.189 43.1628 554.861 42.5584 554.527Z" fill="#6B7280"/>
<path d="M0 568H59V572C59 573.105 58.1046 574 57 574H2C0.89543 574 0 573.105 0 572V568Z" fill="#1555e2"/>
<path d="M100 530.5V568H159C159 559 139 555 131 549.5C124.6 545.1 123.667 535 124 530.5H100Z" fill="#374151"/>
<path d="M100 568H159V572C159 573.105 158.105 574 157 574H102C100.895 574 100 573.105 100 572V568Z" fill="#2563eb"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M110.5 555C112.433 555 114 553.433 114 551.5C114 549.567 112.433 548 110.5 548C108.567 548 107 549.567 107 551.5C107 553.433 108.567 555 110.5 555ZM110.5 557C113.538 557 116 554.538 116 551.5C116 548.462 113.538 546 110.5 546C107.462 546 105 548.462 105 551.5C105 554.538 107.462 557 110.5 557Z" fill="#6B7280"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M141.484 554.602L140.651 555.435C137.088 558.998 132.255 561 127.216 561H100V563H127.216C132.785 563 138.127 560.788 142.065 556.849L143.475 555.44C142.853 555.177 142.232 554.916 141.614 554.657C141.571 554.638 141.527 554.62 141.484 554.602Z" fill="#6B7280"/>
<path d="M92.2945 531.731L69.5 335.5L43.2322 531.765C43.0993 532.758 42.2519 533.5 41.2499 533.5H2.71603C1.53063 533.5 0.605358 532.475 0.726496 531.296L32.5 222H106L133.804 531.321C133.909 532.491 132.987 533.5 131.812 533.5H94.2812C93.2659 533.5 92.4117 532.739 92.2945 531.731Z" fill="#2563eb"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M26.6709 533.5L63.4999 286.5L69.4681 335.738L43.2321 531.765C43.0992 532.758 42.2518 533.5 41.2498 533.5H26.6709ZM70.895 347.509L73.4658 369.641L73.4999 369L70.895 347.509Z" fill="url(#paint3_linear_182_7956)"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M71 244V260C71 266.627 76.3726 272 83 272C89.6274 272 95 266.627 95 260V244H71ZM70.8824 242C69.8428 242 69 242.843 69 243.882V260C69 267.732 75.268 274 83 274C90.732 274 97 267.732 97 260V243.882C97 242.843 96.1572 242 95.1176 242H70.8824Z" fill="#c8d8fa" fill-opacity="0.4"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M35 244V261C35 267.075 39.9249 272 46 272C52.0751 272 57 267.075 57 261V244H35ZM34.8824 242C33.8428 242 33 242.843 33 243.882V261C33 268.18 38.8203 274 46 274C53.1797 274 59 268.18 59 261V243.882C59 242.843 58.1572 242 57.1176 242H34.8824Z" fill="#c8d8fa" fill-opacity="0.4"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M45 521L1 521L1 519L45 519L45 521Z" fill="#c8d8fa"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M133 521L90 521L90 519L133 519L133 521Z" fill="#c8d8fa"/>
<path d="M47.4999 77.4998C52.2999 84.6998 55.1666 92.1665 55.9999 94.9999L68 92.4999L78 58.9998C86 49.9998 70.5 43 60 44.9998C50.5695 46.796 47.9999 52.3332 47.9999 55.9998C37.9999 55.9998 41.4999 68.4998 47.4999 77.4998Z" fill="#111928"/>
<path d="M75.5 116L72.5 88.0002C70.3333 82.8335 66 74.2002 66 81.0002C66 87.8002 59.3333 93.1668 56 95.0002C55.6 104.2 49.8333 115.167 47 119.5L75.5 116Z" fill="#FDBA8C"/>
<path d="M75.5 116L72.5 88.0002C70.3333 82.8335 66 74.2002 66 81.0002C66 87.8002 59.3333 93.1668 56 95.0002C55.6 104.2 49.8333 115.167 47 119.5L75.5 116Z" fill="url(#paint4_linear_182_7956)"/>
<path d="M61.9996 69.5C60.4996 76.5 66.4996 91.5 76.9996 90C81.5087 89.3559 83.436 84.0091 83.6922 77.7215C83.7245 76.9312 85.5188 77.8126 85.5 77C85.4736 75.8565 83.6099 73.0118 83.4911 71.8598C82.8019 65.1776 80.6435 58.7031 77.9996 56.5C77.1664 56 75.1154 57.5 74.5 61.5C73.5 68 71 71 69.5 69.5C67.596 67.5961 63.4996 62.5 61.9996 69.5Z" fill="#FDBA8C"/>
<path d="M79.1344 70.3016C79.0387 70.8678 79.4201 71.4045 79.9863 71.5003C80.5526 71.596 81.0893 71.2146 81.185 70.6483C81.2808 70.0821 80.8994 69.5454 80.3331 69.4497C79.7668 69.3539 79.2302 69.7353 79.1344 70.3016Z" fill="#111928"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M80.956 66.6133C81.6792 66.7449 82.216 67.1504 82.6997 67.6756C82.8868 67.8787 83.2031 67.8917 83.4062 67.7047C83.6094 67.5176 83.6224 67.2013 83.4353 66.9982C82.8765 66.3915 82.1575 65.8155 81.1349 65.6295C80.1178 65.4445 78.8861 65.6608 77.3274 66.4523C77.0812 66.5774 76.983 66.8783 77.108 67.1246C77.233 67.3708 77.534 67.469 77.7802 67.344C79.2235 66.6111 80.2275 66.4808 80.956 66.6133Z" fill="#111928"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M82.6891 69.7746C82.4368 69.8868 82.3232 70.1823 82.4355 70.4346L85.231 76.7201C85.2809 76.8323 85.2148 76.9621 85.0946 76.9876L82.212 77.6007C81.9419 77.6581 81.7695 77.9236 81.827 78.1937C81.8844 78.4638 82.1499 78.6362 82.42 78.5788L85.3026 77.9658C86.0446 77.8079 86.453 77.0069 86.1447 76.3137L83.3492 70.0282C83.2369 69.7759 82.9414 69.6623 82.6891 69.7746Z" fill="#111928"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M79.3756 82.5792C78.6136 82.2662 78.0914 81.6434 77.8802 80.8683C77.8076 80.6019 77.5327 80.4448 77.2663 80.5174C76.9999 80.59 76.8428 80.8649 76.9154 81.1313C77.204 82.1901 77.9317 83.0672 78.9957 83.5042C80.0576 83.9404 81.3986 83.917 82.8934 83.2952C83.1483 83.1891 83.269 82.8965 83.163 82.6415C83.0569 82.3865 82.7642 82.2658 82.5093 82.3719C81.2004 82.9164 80.1396 82.893 79.3756 82.5792Z" fill="#111928"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M64.8286 72.0405C64.775 71.3074 65.0333 70.6862 65.4208 70.0865C65.5706 69.8545 65.504 69.545 65.2721 69.3952C65.0401 69.2453 64.7306 69.3119 64.5808 69.5438C64.1333 70.2366 63.7554 71.0769 63.8312 72.1135C63.9066 73.1446 64.4243 74.2829 65.5806 75.594C65.7633 75.8011 66.0793 75.8209 66.2864 75.6382C66.4935 75.4555 66.5133 75.1396 66.3306 74.9325C65.2599 73.7185 64.8826 72.7791 64.8286 72.0405Z" fill="#111928"/>
<path d="M259 114C259.5 120 230 129 229.5 129L223.5 120.5L242 108V111C247.5 110 258.6 109.2 259 114Z" fill="#FDBA8C"/>
<path d="M259 114C259.5 120 230 129 229.5 129L223.5 120.5L242 108V111C247.5 110 258.6 109.2 259 114Z" fill="url(#paint5_linear_182_7956)"/>
<path d="M109 227H29.5C29.5 218.5 30.5 193.5 30.5 169.5C30.5 133.486 43.5 112 47 112C50.5 112 55 114 61.5 114C68 114 71 110 82 112C90.8 113.6 125.667 135.333 142 146L224.758 115.639C225.741 115.279 226.835 115.736 227.268 116.689L233.226 129.797C233.662 130.756 233.28 131.887 232.353 132.386L156.602 173.143C147.515 178.033 136.553 177.909 127.579 172.815L105 160L109 227Z" fill="#F9FAFB"/>
<path d="M109 227H29.5C29.5 218.5 30.5 193.5 30.5 169.5C30.5 133.486 43.5 112 47 112C50.5 112 55 114 61.5 114C68 114 71 110 82 112C90.8 113.6 125.667 135.333 142 146L224.758 115.639C225.741 115.279 226.835 115.736 227.268 116.689L233.226 129.797C233.662 130.756 233.28 131.887 232.353 132.386L156.602 173.143C147.515 178.033 136.553 177.909 127.579 172.815L105 160L109 227Z" fill="url(#paint6_linear_182_7956)"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M80.5 227H109L105.011 160.188L80.5 146.5V227Z" fill="url(#paint7_linear_182_7956)"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M109 220H29V218H109V220Z" fill="#c8d8fa"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M222.096 138.428L213.096 119.428L214.903 118.572L223.903 137.572L222.096 138.428Z" fill="#c8d8fa"/>
<defs>
<linearGradient id="paint0_linear_182_7956" x1="396.5" y1="552" x2="396.5" y2="313" gradientUnits="userSpaceOnUse">
<stop stop-color="#F9FAFB"/>
<stop offset="1" stop-color="#F9FAFB" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint1_linear_182_7956" x1="389" y1="411" x2="389" y2="548" gradientUnits="userSpaceOnUse">
<stop stop-color="#9ab7f6"/>
<stop offset="1" stop-color="#9ab7f6" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint2_linear_182_7956" x1="452.641" y1="545.369" x2="610.197" y2="545.369" gradientUnits="userSpaceOnUse">
<stop stop-color="#9ab7f6"/>
<stop offset="1" stop-color="#9ab7f6" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint3_linear_182_7956" x1="212.935" y1="188.375" x2="187.582" y2="456.683" gradientUnits="userSpaceOnUse">
<stop stop-color="#111928"/>
<stop offset="1" stop-color="#111928" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint4_linear_182_7956" x1="93" y1="59.5" x2="58.3002" y2="97.8512" gradientUnits="userSpaceOnUse">
<stop stop-color="#7F270F"/>
<stop offset="1" stop-color="#7F270F" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint5_linear_182_7956" x1="185" y1="161.5" x2="184.521" y2="114.386" gradientUnits="userSpaceOnUse">
<stop stop-color="#7F270F"/>
<stop offset="1" stop-color="#7F270F" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint6_linear_182_7956" x1="43" y1="-10" x2="105" y2="169" gradientUnits="userSpaceOnUse">
<stop stop-color="#c8d8fa"/>
<stop offset="1" stop-color="#c8d8fa" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint7_linear_182_7956" x1="173.048" y1="147.063" x2="107.499" y2="221.48" gradientUnits="userSpaceOnUse">
<stop stop-color="#c8d8fa"/>
<stop offset="1" stop-color="#c8d8fa" stop-opacity="0"/>
</linearGradient>
</defs>
</svg>
                        </div>
                        <div class="text-gray-500 text-sm">No notifications yet. Send your first notification.</div>
                    </div>
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full text-left">
                        <thead class="bg-gray-50">
                            <tr class="text-sm text-gray-700">
                                <th class="px-4 py-2">Title</th>
                                <th class="px-4 py-2">Message</th>
                                <th class="px-4 py-2">Scheduled</th>
                                <th class="px-4 py-2 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100 text-sm">
                            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-4 py-2 text-gray-900"><?php echo e($n->title); ?></td>
                                    <td class="px-4 py-2 text-gray-700"><?php echo e(\Illuminate\Support\Str::limit($n->message, 90)); ?></td>
                                    <td class="px-4 py-2 text-gray-600"><?php echo e($n->scheduled_at?->format('Y-m-d H:i') ?? '—'); ?></td>
                                    <td class="px-4 py-2">
                                        <div class="flex items-center justify-end gap-2">
                                            <button class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50">
                                                <span class="material-symbols-outlined text-[18px]">insights</span>
                                                Stats
                                            </button>
                                            <button class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50">
                                                <span class="material-symbols-outlined text-[18px]">replay</span>
                                                Re-send
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\NOVO\Desktop\wazaelimuadminpanelofapp\wazaelimu\resources\views/admin/mobile/notifications/index.blade.php ENDPATH**/ ?>