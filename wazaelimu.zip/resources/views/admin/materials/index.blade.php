<x-admin-layout>
    <div class="py-4">
        <div class="flex items-center justify-between mb-2">
            <div>
                <h1 class="text-xl font-semibold text-gray-900">All Materials</h1>
                <p class="text-sm text-gray-500">Search, add, and manage learning materials.</p>
            </div>
            <button id="btnOpenAddMaterial" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-sm shadow">
                <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4" /></svg>
                <span>Add Material</span>
            </button>
        </div>
        <div class="border-t border-dashed mb-4"></div>

        <div class="mb-3 flex items-start justify-between gap-4">
            <form method="GET" class="flex items-center gap-2 relative" autocomplete="off">
                <div class="relative">
                    <input id="materialSearchInput" type="text" name="q" value="{{ $q ?? '' }}" placeholder="Search materials..." class="w-72 border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                    <div id="materialSuggestBox" class="absolute z-10 mt-1 w-full bg-white border rounded-lg shadow hidden max-h-56 overflow-auto"></div>
                </div>
                <button class="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 text-sm">
                    <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="m21 21-6-6m2-5a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z"/></svg>
                    <span>Search</span>
                </button>
            </form>
        </div>

        <div class="mt-4 bg-white border rounded-lg overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-gray-50 text-gray-700">
                    <tr class="text-sm">
                        <th class="px-4 py-3 font-medium">Title</th>
                        <th class="px-4 py-3 font-medium">Category</th>
                        <th class="px-4 py-3 font-medium">Subcategory</th>
                        <th class="px-4 py-3 font-medium">URL</th>
                        <th class="px-4 py-3 font-medium text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse(($materials ?? []) as $mat)
                        <tr class="text-sm">
                            <td class="px-4 py-3 text-gray-900">{{ $mat->title }}</td>
                            <td class="px-4 py-3 text-gray-700">{{ $mat->category->name ?? '-' }}</td>
                            <td class="px-4 py-3 text-gray-700">{{ $mat->subcategory->name ?? '-' }}</td>
                            <td class="px-4 py-3">
                                @if($mat->url)
                                    <a href="{{ $mat->url }}" target="_blank" class="text-indigo-600 hover:underline">Open</a>
                                @else
                                    <span class="text-gray-400">—</span>
                                @endif
                            </td>
                            <td class="px-4 py-3">
                                <div class="flex items-center justify-end gap-2">
                                    <button
                                        class="btnEditMaterial inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50"
                                        data-id="{{ $mat->id }}"
                                        data-title="{{ $mat->title }}"
                                        data-category-id="{{ $mat->category_id }}"
                                        data-subcategory-id="{{ $mat->subcategory_id }}"
                                        data-url="{{ $mat->url }}"
                                    >
                                        <span class="material-symbols-outlined text-[18px]">edit</span>
                                        <span class="text-sm">Edit</span>
                                    </button>
                                    <form class="js-confirm-delete" method="POST" action="{{ route('materials.destroy', $mat) }}" data-confirm-title="Delete Material" data-confirm-message="Are you sure you want to delete this material?">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50">
                                            <span class="material-symbols-outlined text-[18px]">delete</span>
                                            <span class="text-sm">Delete</span>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="px-4 py-10 text-center">
                                <div class="flex flex-col items-center justify-center gap-4">
                                    <div class="text-gray-800">
                                        <!-- Empty state illustration -->
                                        <svg class="w-auto max-w-[16rem] h-40 text-gray-800" aria-hidden="true" width="411" height="578" viewBox="0 0 411 578" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M59 6C59 2.68629 61.6863 0 65 0H261C264.314 0 267 2.68629 267 6V245C267 248.314 264.314 251 261 251H65C61.6863 251 59 248.314 59 245V6Z" fill="#d6e2fb"/>
<path d="M200 64.5C200 84.6584 183.658 101 163.5 101C143.342 101 127 84.6584 127 64.5C127 44.3416 143.342 28 163.5 28C183.658 28 200 44.3416 200 64.5Z" fill="white"/>
<path d="M86 120C86 118.895 86.8954 118 88 118H158C159.105 118 160 118.895 160 120V132C160 133.105 159.105 134 158 134H88C86.8954 134 86 133.105 86 132V120Z" fill="white"/>
<path d="M166 120C166 118.895 166.895 118 168 118H238C239.105 118 240 118.895 240 120V132C240 133.105 239.105 134 238 134H168C166.895 134 166 133.105 166 132V120Z" fill="white"/>
<path d="M86 144C86 142.895 86.8954 142 88 142H158C159.105 142 160 142.895 160 144V156C160 157.105 159.105 158 158 158H88C86.8954 158 86 157.105 86 156V144Z" fill="white"/>
<path d="M86 167C86 165.895 86.8954 165 88 165H238C239.105 165 240 165.895 240 167V179C240 180.105 239.105 181 238 181H88C86.8954 181 86 180.105 86 179V167Z" fill="white"/>
<path d="M166 144C166 142.895 166.895 142 168 142H238C239.105 142 240 142.895 240 144V156C240 157.105 239.105 158 238 158H168C166.895 158 166 157.105 166 156V144Z" fill="white"/>
<path d="M163.698 62.6481C167.467 62.6481 170.522 59.5929 170.522 55.824C170.522 52.0552 167.467 49 163.698 49C159.93 49 156.874 52.0552 156.874 55.824C156.874 59.5929 159.93 62.6481 163.698 62.6481Z" fill="#d6e2fb"/>
<path d="M159.799 68.4973H167.598C169.666 68.4973 171.65 69.3189 173.112 70.7815C174.575 72.2441 175.397 74.2278 175.397 76.2962V80.1956H152V76.2962C152 74.2278 152.822 72.2441 154.284 70.7815C155.747 69.3189 157.731 68.4973 159.799 68.4973Z" fill="#d6e2fb"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M94.6133 126C94.6133 125.234 95.234 124.613 95.9998 124.613L134 124.613C134.765 124.613 135.386 125.234 135.386 126C135.386 126.765 134.765 127.386 134 127.386L95.9998 127.386C95.234 127.386 94.6133 126.765 94.6133 126Z" fill="#d6e2fb"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M174.613 126C174.613 125.234 175.234 124.613 176 124.613L208 124.613C208.765 124.613 209.386 125.234 209.386 126C209.386 126.765 208.765 127.386 208 127.386L176 127.386C175.234 127.386 174.613 126.765 174.613 126Z" fill="#d6e2fb"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M94.6133 150C94.6133 149.234 95.234 148.613 95.9998 148.613L134 148.613C134.765 148.613 135.386 149.234 135.386 150C135.386 150.765 134.765 151.386 134 151.386L95.9998 151.386C95.234 151.386 94.6133 150.765 94.6133 150Z" fill="#d6e2fb"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M174.613 126C174.613 125.234 175.234 124.613 176 124.613L208 124.613C208.765 124.613 209.386 125.234 209.386 126C209.386 126.765 208.765 127.386 208 127.386L176 127.386C175.234 127.386 174.613 126.765 174.613 126Z" fill="#d6e2fb"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M174.613 150C174.613 149.234 175.234 148.613 176 148.613L208 148.613C208.765 148.613 209.386 149.234 209.386 150C209.386 150.765 208.765 151.386 208 151.386L176 151.386C175.234 151.386 174.613 150.765 174.613 150Z" fill="#d6e2fb"/>
<path d="M122.525 173.263C122.525 174.512 121.512 175.525 120.263 175.525C119.013 175.525 118 174.512 118 173.263C118 172.013 119.013 171 120.263 171C121.512 171 122.525 172.013 122.525 173.263Z" fill="#d6e2fb"/>
<path d="M131.073 173.263C131.073 174.512 130.06 175.525 128.81 175.525C127.561 175.525 126.548 174.512 126.548 173.263C126.548 172.013 127.561 171 128.81 171C130.06 171 131.073 172.013 131.073 173.263Z" fill="#d6e2fb"/>
<path d="M139.62 173.263C139.62 174.512 138.607 175.525 137.357 175.525C136.108 175.525 135.095 174.512 135.095 173.263C135.095 172.013 136.108 171 137.357 171C138.607 171 139.62 172.013 139.62 173.263Z" fill="#d6e2fb"/>
<path d="M148.168 173.263C148.168 174.512 147.155 175.525 145.905 175.525C144.656 175.525 143.643 174.512 143.643 173.263C143.643 172.013 144.656 171 145.905 171C147.155 171 148.168 172.013 148.168 173.263Z" fill="#d6e2fb"/>
<path d="M156.715 173.263C156.715 174.512 155.702 175.525 154.452 175.525C153.202 175.525 152.189 174.512 152.189 173.263C152.189 172.013 153.202 171 154.452 171C155.702 171 156.715 172.013 156.715 173.263Z" fill="#d6e2fb"/>
<path d="M165.262 173.263C165.262 174.512 164.249 175.525 163 175.525C161.75 175.525 160.737 174.512 160.737 173.263C160.737 172.013 161.75 171 163 171C164.249 171 165.262 172.013 165.262 173.263Z" fill="#d6e2fb"/>
<path d="M173.81 173.263C173.81 174.512 172.797 175.525 171.548 175.525C170.298 175.525 169.285 174.512 169.285 173.263C169.285 172.013 170.298 171 171.548 171C172.797 171 173.81 172.013 173.81 173.263Z" fill="#d6e2fb"/>
<path d="M182.357 173.263C182.357 174.512 181.344 175.525 180.095 175.525C178.845 175.525 177.832 174.512 177.832 173.263C177.832 172.013 178.845 171 180.095 171C181.344 171 182.357 172.013 182.357 173.263Z" fill="#d6e2fb"/>
<path d="M190.905 173.263C190.905 174.512 189.892 175.525 188.642 175.525C187.393 175.525 186.38 174.512 186.38 173.263C186.38 172.013 187.393 171 188.642 171C189.892 171 190.905 172.013 190.905 173.263Z" fill="#d6e2fb"/>
<path d="M199.453 173.263C199.453 174.512 198.44 175.525 197.19 175.525C195.941 175.525 194.928 174.512 194.928 173.263C194.928 172.013 195.941 171 197.19 171C198.44 171 199.453 172.013 199.453 173.263Z" fill="#d6e2fb"/>
<path d="M208.001 173.263C208.001 174.512 206.988 175.525 205.738 175.525C204.489 175.525 203.476 174.512 203.476 173.263C203.476 172.013 204.489 171 205.738 171C206.988 171 208.001 172.013 208.001 173.263Z" fill="#d6e2fb"/>
<path d="M143.729 164.549C143.364 163.272 144.323 162 145.652 162H214.492C215.384 162 216.169 162.592 216.415 163.451L230 211H157L143.729 164.549Z" fill="#2563eb"/>
<path d="M230 211H272.5C273.328 211 274 211.672 274 212.5C274 213.328 273.328 214 272.5 214H230V211Z" fill="#111928"/>
<path d="M230 211H157V212C157 213.105 157.895 214 159 214H230V211Z" fill="#111928"/>
<path d="M189.808 186.889C190.255 188.485 189.273 189.778 187.617 189.778C185.96 189.778 184.255 188.485 183.808 186.889C183.362 185.293 184.343 184 186 184C187.657 184 189.362 185.293 189.808 186.889Z" fill="#d6e2fb"/>
<path d="M288 219H234V578H288V219Z" fill="url(#paint0_linear_182_7952)"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M287 578L287 221L289 221L289 578L287 578Z" fill="#d6e2fb"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M287 578L287 221L289 221L289 578L287 578Z" fill="url(#paint1_linear_182_7952)"/>
<path d="M128 219H234V578H128V219Z" fill="url(#paint2_linear_182_7952)"/>
<path d="M123 216C123 214.895 123.895 214 125 214H291C292.105 214 293 214.895 293 216V219C293 220.105 292.105 221 291 221H125C123.895 221 123 220.105 123 219V216Z" fill="#d6e2fb"/>
<path d="M123 216C123 214.895 123.895 214 125 214H291C292.105 214 293 214.895 293 216V219C293 220.105 292.105 221 291 221H125C123.895 221 123 220.105 123 219V216Z" fill="url(#paint3_linear_182_7952)"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M233 578L233 221L235 221L235 578L233 578Z" fill="#d6e2fb"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M233 578L233 221L235 221L235 578L233 578Z" fill="url(#paint4_linear_182_7952)"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M127 578L127 221L129 221L129 578L127 578Z" fill="#d6e2fb"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M127 578L127 221L129 221L129 578L127 578Z" fill="url(#paint5_linear_182_7952)"/>
<path d="M230 216C230 214.895 230.895 214 232 214H291C292.105 214 293 214.895 293 216V219C293 220.105 292.105 221 291 221H232C230.895 221 230 220.105 230 219V216Z" fill="#d6e2fb"/>
<path d="M230 216C230 214.895 230.895 214 232 214H291C292.105 214 293 214.895 293 216V219C293 220.105 292.105 221 291 221H232C230.895 221 230 220.105 230 219V216Z" fill="url(#paint6_linear_182_7952)"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M61.698 358.891C61.698 361.233 61.2716 363.476 60.4922 365.546C59.8438 367.268 60.288 369.285 61.6937 370.472C68.0559 375.844 72.0966 383.88 72.0966 392.859C72.0966 396.037 71.5907 399.096 70.6549 401.961C70.1692 403.448 70.5784 405.105 71.7407 406.152C80.4721 414.019 85.9613 425.415 85.9613 438.093C85.9613 461.83 66.7182 481.074 42.9807 481.074C19.2431 481.074 0 461.83 0 438.093C0 425.533 5.38707 414.232 13.9766 406.373C15.131 405.317 15.5275 403.657 15.0303 402.174C14.0495 399.248 13.5181 396.116 13.5181 392.859C13.5181 383.88 17.5588 375.844 23.9209 370.472C25.3267 369.285 25.7708 367.268 25.1225 365.546C24.3431 363.476 23.9167 361.233 23.9167 358.891C23.9167 348.458 32.3743 340 42.8073 340C53.2404 340 61.698 348.458 61.698 358.891Z" fill="#d6e2fb"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M42.6338 357.717C43.1861 357.717 43.6338 358.165 43.6338 358.717L43.6338 524.747C43.6338 525.3 43.1861 525.747 42.6338 525.747C42.0815 525.747 41.6338 525.3 41.6338 524.747L41.6338 358.717C41.6338 358.165 42.0815 357.717 42.6338 357.717Z" fill="#9ab7f6"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M62.2796 432.774C62.729 433.095 62.8331 433.719 62.512 434.169L43.4481 460.858C43.127 461.308 42.5025 461.412 42.0531 461.091C41.6037 460.77 41.4996 460.145 41.8206 459.696L60.8846 433.006C61.2056 432.557 61.8301 432.453 62.2796 432.774Z" fill="#9ab7f6"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M22.989 391.526C22.5396 391.847 22.4355 392.471 22.7565 392.921L41.8205 419.61C42.1415 420.06 42.7661 420.164 43.2155 419.843C43.6649 419.522 43.769 418.897 43.448 418.448L24.384 391.758C24.063 391.309 23.4384 391.205 22.989 391.526Z" fill="#9ab7f6"/>
<path d="M15.6895 500.839C15.6396 499.701 16.5486 498.751 17.6875 498.751H67.9273C69.0663 498.751 69.9753 499.701 69.9254 500.839L66.6346 575.868C66.5877 576.937 65.7071 577.78 64.6366 577.78H20.9783C19.9078 577.78 19.0271 576.937 18.9802 575.868L15.6895 500.839Z" fill="#d6e2fb"/>
<path d="M15.6895 500.839C15.6396 499.701 16.5486 498.751 17.6875 498.751H67.9273C69.0663 498.751 69.9753 499.701 69.9254 500.839L66.6346 575.868C66.5877 576.937 65.7071 577.78 64.6366 577.78H20.9783C19.9078 577.78 19.0271 576.937 18.9802 575.868L15.6895 500.839Z" fill="url(#paint7_linear_182_7952)"/>
<path d="M356.443 560.5C348.843 563.7 342.61 567.5 340.443 569L339.443 572L339.943 573.5L342.943 576.5C364.11 575.333 406.643 571.7 407.443 566.5C408.443 560 405.397 556.087 402.943 549C400 540.5 400 534.167 400 530.5H379.443C377.443 549 365.943 556.5 356.443 560.5Z" fill="#F9FAFB"/>
<path d="M356.443 560.5C348.843 563.7 342.61 567.5 340.443 569L339.443 572L339.943 573.5L342.943 576.5C364.11 575.333 406.643 571.7 407.443 566.5C408.443 560 405.397 556.087 402.943 549C400 540.5 400 534.167 400 530.5H379.443C377.443 549 365.943 556.5 356.443 560.5Z" fill="url(#paint8_linear_182_7952)"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M356.913 560.3L363.037 573.423L364.849 572.577L358.737 559.478C358.123 559.768 357.515 560.041 356.913 560.3ZM371.033 550.632L386.187 568.154L387.7 566.846L372.336 549.081C371.913 549.619 371.478 550.135 371.033 550.632Z" fill="#2563eb"/>
<path d="M346.443 575C340.043 575 339.776 571 340.443 569C335.643 572.2 337.776 576 339.443 577.5H405.943C407.048 577.5 407.943 576.605 407.943 575.5V566.5C399.443 559 354.443 575 346.443 575Z" fill="#374151"/>
<path d="M295.5 560.5C287.9 563.7 281.667 567.5 279.5 569L278.5 572L279 573.5L282 576.5C303.167 575.333 345.7 571.7 346.5 566.5C347.5 560 342 556.5 342 549V530.5H318.5C316.5 549 305 556.5 295.5 560.5Z" fill="#F9FAFB"/>
<path d="M295.5 560.5C287.9 563.7 281.667 567.5 279.5 569L278.5 572L279 573.5L282 576.5C303.167 575.333 345.7 571.7 346.5 566.5C347.5 560 342 556.5 342 549V530.5H318.5C316.5 549 305 556.5 295.5 560.5Z" fill="url(#paint9_linear_182_7952)"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M295.97 560.3L302.094 573.423L303.906 572.577L297.793 559.478C297.18 559.768 296.571 560.041 295.97 560.3ZM310.09 550.632L325.243 568.154L326.756 566.846L311.392 549.081C310.97 549.619 310.535 550.135 310.09 550.632Z" fill="#2563eb"/>
<path d="M285.5 575C279.1 575 278.833 571 279.5 569C274.7 572.2 276.833 576 278.5 577.5H345C346.104 577.5 347 576.605 347 575.5V566.5C338.5 559 293.5 575 285.5 575Z" fill="#374151"/>
<path d="M364.173 530.9L354.5 483.5L370.5 351L410.457 530.064C410.735 531.314 409.785 532.5 408.505 532.5H366.133C365.183 532.5 364.363 531.831 364.173 530.9Z" fill="#2563eb"/>
<path d="M364.173 530.9L354.5 483.5L370.5 351L410.457 530.064C410.735 531.314 409.785 532.5 408.505 532.5H366.133C365.183 532.5 364.363 531.831 364.173 530.9Z" fill="url(#paint10_linear_182_7952)"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M408 518H361V516H408V518Z" fill="#c8d8fa"/>
<path d="M350.769 533H303.197C302.019 533 301.096 531.986 301.206 530.812L331.5 209.5H377C388.13 255.213 365.617 441.986 352.741 531.332C352.599 532.315 351.763 533 350.769 533Z" fill="#2563eb"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M318.752 346.031C329.273 346.616 337.625 355.333 337.625 366C337.625 377.046 328.67 386 317.625 386C316.735 386 315.859 385.942 315 385.829L315.188 383.836C315.985 383.944 316.798 384 317.625 384C327.566 384 335.625 375.941 335.625 366C335.625 356.374 328.069 348.513 318.564 348.024L318.752 346.031Z" fill="#c8d8fa"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M355 518H303V516H355V518Z" fill="#d6e2fb"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M408 518H362V516H408V518Z" fill="#d6e2fb"/>
<path d="M326 199L327 186H340.5C341 194 340.5 210.6 334.5 213C328.5 215.4 279.667 209.667 256 206.5C252.4 208.5 247.333 210.167 245 211H239C240.6 205 251.333 202 256.5 201L326 199Z" fill="#FDBA8C"/>
<path d="M326 199L327 186H340.5C341 194 340.5 210.6 334.5 213C328.5 215.4 279.667 209.667 256 206.5C252.4 208.5 247.333 210.167 245 211H239C240.6 205 251.333 202 256.5 201L326 199Z" fill="url(#paint11_linear_182_7952)"/>
<path d="M347.5 106.5C344.7 103.7 342.667 95.0002 342 91.0002C338.333 95.3336 329.3 99.2002 322.5 80.0002C314 56.0002 336.5 54.5002 350.5 63.0002C361.025 69.3903 366.781 91.8816 368.681 104.251C368.865 105.443 367.932 106.5 366.726 106.5H347.5Z" fill="#d6e2fb"/>
<path d="M347.5 106.5C344.7 103.7 342.667 95.0002 342 91.0002C338.333 95.3336 329.3 99.2002 322.5 80.0002C314 56.0002 336.5 54.5002 350.5 63.0002C361.025 69.3903 366.781 91.8816 368.681 104.251C368.865 105.443 367.932 106.5 366.726 106.5H347.5Z" fill="url(#paint12_linear_182_7952)"/>
<path d="M340.5 118.5L333.5 97L342.5 88.5L352.5 114.5L340.5 118.5Z" fill="#FDBA8C"/>
<path d="M340.5 118.5L333.5 97L342.5 88.5L352.5 114.5L340.5 118.5Z" fill="url(#paint13_linear_182_7952)"/>
<path d="M327.5 99C320.7 95 322 76.6667 323.5 68C327.001 68.5 336 85 339 83.5C342 82 346 77.5 347 82.5C348 87.5 336 104 327.5 99Z" fill="#FDBA8C"/>
<path d="M328.837 82.3016C328.933 82.8678 328.552 83.4045 327.985 83.5003C327.419 83.596 326.882 83.2146 326.787 82.6483C326.691 82.0821 327.072 81.5454 327.639 81.4497C328.205 81.3539 328.742 81.7353 328.837 82.3016Z" fill="#111928"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M327.016 78.6133C326.292 78.7449 325.756 79.1504 325.272 79.6756C325.085 79.8787 324.769 79.8917 324.565 79.7047C324.362 79.5176 324.349 79.2013 324.536 78.9982C325.095 78.3915 325.814 77.8155 326.837 77.6295C327.854 77.4445 329.086 77.6608 330.644 78.4523C330.89 78.5774 330.989 78.8783 330.864 79.1246C330.739 79.3708 330.438 79.469 330.191 79.344C328.748 78.6111 327.744 78.4808 327.016 78.6133Z" fill="#111928"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M323.719 81.7627C323.992 81.8036 324.18 82.0581 324.139 82.3312L323.121 89.1345C323.103 89.256 323.201 89.3634 323.324 89.356L326.266 89.1781C326.541 89.1615 326.778 89.3714 326.795 89.647C326.812 89.9227 326.602 90.1596 326.326 90.1763L323.384 90.3542C322.627 90.4 322.02 89.7368 322.132 88.9866L323.15 82.1832C323.191 81.9101 323.446 81.7218 323.719 81.7627Z" fill="#111928"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M328.32 93.0158C329.021 92.6106 329.51 91.9358 329.829 91.0585C329.924 90.799 330.21 90.6651 330.47 90.7594C330.729 90.8538 330.863 91.1407 330.769 91.4002C330.395 92.4293 329.781 93.3265 328.821 93.8816C327.86 94.4371 326.621 94.61 325.077 94.325C324.806 94.2748 324.626 94.014 324.676 93.7425C324.726 93.4709 324.987 93.2914 325.259 93.3416C326.64 93.5965 327.62 93.4206 328.32 93.0158Z" fill="#111928"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M344.321 85.3502C344.607 84.6729 344.561 84.0017 344.386 83.3094C344.319 83.0416 344.481 82.7698 344.749 82.7021C345.016 82.6345 345.288 82.7967 345.356 83.0644C345.558 83.864 345.646 84.7811 345.243 85.7387C344.841 86.6914 343.986 87.6038 342.47 88.4754C342.231 88.613 341.925 88.5306 341.788 88.2912C341.65 88.0518 341.732 87.7462 341.972 87.6085C343.375 86.8015 344.033 86.0325 344.321 85.3502Z" fill="#111928"/>
<path d="M323.758 185.771L328 149L336 188H325.744C324.549 188 323.621 186.958 323.758 185.771Z" fill="#F9FAFB"/>
<path d="M323.758 185.771L328 149L336 188H325.744C324.549 188 323.621 186.958 323.758 185.771Z" fill="url(#paint14_linear_182_7952)"/>
<path d="M377.5 209.5V190.5L372 191L364.5 209.5H377.5Z" fill="#F9FAFB"/>
<path d="M377.5 209.5V190.5L372 191L364.5 209.5H377.5Z" fill="url(#paint15_linear_182_7952)"/>
<path d="M331.5 210H362.5L373.5 193.5C383.5 193.5 383.5 188 383.5 188C379.5 144.8 373.5 116 351 109C347 112.6 340.333 114.167 337.5 114.5C335.5 119.333 330.9 132.4 328.5 146C326.1 159.6 329.5 176.667 331.5 183.5V210Z" fill="#F9FAFB"/>
<path d="M331.5 210H362.5L373.5 193.5C383.5 193.5 383.5 188 383.5 188C379.5 144.8 373.5 116 351 109C347 112.6 340.333 114.167 337.5 114.5C335.5 119.333 330.9 132.4 328.5 146C326.1 159.6 329.5 176.667 331.5 183.5V210Z" fill="url(#paint16_linear_182_7952)"/>
<path d="M346.5 193.5H351V203L346.5 193.5Z" fill="url(#paint17_linear_182_7952)"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M348 158V193.5H346V158H348Z" fill="#c8d8fa"/>
<path d="M259.5 201C250.7 200.6 244.5 207.333 242.5 211H253.5L262 207.5C287 213 340.4 224.1 354 224.5C367.6 224.9 373.333 204 374.5 193.5H351V205.5C324.167 204.167 268.3 201.4 259.5 201Z" fill="#FDBA8C"/>
<path d="M259.5 201C250.7 200.6 244.5 207.333 242.5 211H253.5L262 207.5C287 213 340.4 224.1 354 224.5C367.6 224.9 373.333 204 374.5 193.5H351V205.5C324.167 204.167 268.3 201.4 259.5 201Z" fill="url(#paint18_linear_182_7952)"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M348 158V193.5H346V158H348Z" fill="#c8d8fa"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M318.752 346.031C329.273 346.616 337.625 355.333 337.625 366C337.625 377.046 328.67 386 317.625 386C316.735 386 315.859 385.942 315 385.829L315.188 383.836C315.985 383.944 316.798 384 317.625 384C327.566 384 335.625 375.941 335.625 366C335.625 356.374 328.069 348.513 318.564 348.024L318.752 346.031Z" fill="#c8d8fa"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M355 518H302V516H355V518Z" fill="#c8d8fa"/>
<defs>
<linearGradient id="paint0_linear_182_7952" x1="261" y1="204" x2="261" y2="507" gradientUnits="userSpaceOnUse">
<stop stop-color="#F9FAFB"/>
<stop offset="1" stop-color="#F9FAFB" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint1_linear_182_7952" x1="287.804" y1="221" x2="284.158" y2="221.1" gradientUnits="userSpaceOnUse">
<stop stop-color="#c8d8fa"/>
<stop offset="1" stop-color="#c8d8fa" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint2_linear_182_7952" x1="181" y1="204" x2="181" y2="507" gradientUnits="userSpaceOnUse">
<stop stop-color="#F9FAFB"/>
<stop offset="1" stop-color="#F9FAFB" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint3_linear_182_7952" x1="79.5" y1="206" x2="286" y2="257.5" gradientUnits="userSpaceOnUse">
<stop stop-color="#c8d8fa"/>
<stop offset="1" stop-color="#c8d8fa" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint4_linear_182_7952" x1="233.804" y1="221" x2="230.158" y2="221.1" gradientUnits="userSpaceOnUse">
<stop stop-color="#c8d8fa"/>
<stop offset="1" stop-color="#c8d8fa" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint5_linear_182_7952" x1="127.804" y1="221" x2="124.158" y2="221.1" gradientUnits="userSpaceOnUse">
<stop stop-color="#c8d8fa"/>
<stop offset="1" stop-color="#c8d8fa" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint6_linear_182_7952" x1="213.879" y1="206" x2="294.477" y2="213.449" gradientUnits="userSpaceOnUse">
<stop stop-color="#c8d8fa"/>
<stop offset="1" stop-color="#c8d8fa" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint7_linear_182_7952" x1="135.32" y1="552.369" x2="-22.2363" y2="552.369" gradientUnits="userSpaceOnUse">
<stop stop-color="#9ab7f6"/>
<stop offset="1" stop-color="#9ab7f6" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint8_linear_182_7952" x1="326.077" y1="507.464" x2="322.811" y2="563.088" gradientUnits="userSpaceOnUse">
<stop stop-color="#c8d8fa"/>
<stop offset="1" stop-color="#c8d8fa" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint9_linear_182_7952" x1="265.134" y1="507.464" x2="261.868" y2="563.088" gradientUnits="userSpaceOnUse">
<stop stop-color="#c8d8fa"/>
<stop offset="1" stop-color="#c8d8fa" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint10_linear_182_7952" x1="311.5" y1="375" x2="448.5" y2="425.5" gradientUnits="userSpaceOnUse">
<stop stop-color="#111928"/>
<stop offset="1" stop-color="#111928" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint11_linear_182_7952" x1="487.5" y1="183" x2="229.5" y2="227.5" gradientUnits="userSpaceOnUse">
<stop stop-color="#7F270F"/>
<stop offset="1" stop-color="#7F270F" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint12_linear_182_7952" x1="347.5" y1="111" x2="333" y2="72.5" gradientUnits="userSpaceOnUse">
<stop stop-color="#c8d8fa"/>
<stop offset="1" stop-color="#c8d8fa" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint13_linear_182_7952" x1="343.102" y1="83.0925" x2="343.102" y2="112.096" gradientUnits="userSpaceOnUse">
<stop stop-color="#7F270F"/>
<stop offset="1" stop-color="#7F270F" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint14_linear_182_7952" x1="355.5" y1="134.5" x2="313.937" y2="199.703" gradientUnits="userSpaceOnUse">
<stop stop-color="#c8d8fa"/>
<stop offset="1" stop-color="#c8d8fa" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint15_linear_182_7952" x1="371" y1="180" x2="361.579" y2="196.678" gradientUnits="userSpaceOnUse">
<stop stop-color="#c8d8fa"/>
<stop offset="1" stop-color="#c8d8fa" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint16_linear_182_7952" x1="368.5" y1="-3.00001" x2="368.5" y2="142.5" gradientUnits="userSpaceOnUse">
<stop stop-color="#c8d8fa"/>
<stop offset="1" stop-color="#c8d8fa" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint17_linear_182_7952" x1="347" y1="186" x2="344.165" y2="202.513" gradientUnits="userSpaceOnUse">
<stop stop-color="#c8d8fa"/>
<stop offset="1" stop-color="#c8d8fa" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint18_linear_182_7952" x1="404.5" y1="176.5" x2="360.804" y2="224.114" gradientUnits="userSpaceOnUse">
<stop stop-color="#7F270F"/>
<stop offset="1" stop-color="#7F270F" stop-opacity="0"/>
</linearGradient>
</defs>
</svg>
                                    </div>
                                    <div class="text-gray-500 text-sm">No materials yet. Start by adding one.</div>
                                    <button id="btnOpenAddMaterialEmpty" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-sm shadow">
                                        <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4" /></svg>
                                        <span>Add Material</span>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="mt-4">{{ ($materials ?? null)?->links() }}</div>
    </div>

    <!-- Add Material Modal -->
    <div id="addMaterialModal" class="fixed inset-0 bg-black/30 hidden z-50">
        <div class="min-h-full w-full grid place-items-center p-4">
            <div class="bg-white rounded-lg shadow max-w-lg w-full">
                <div class="px-4 py-3 border-b flex items-center justify-between">
                    <h3 class="font-semibold">Add Material</h3>
                    <button id="btnCloseAddMaterial" class="p-1 hover:bg-gray-100 rounded">
                        <span class="material-symbols-outlined">close</span>
                    </button>
                </div>
                <form method="POST" action="{{ route('materials.store') }}" class="p-4" enctype="multipart/form-data">
                    @csrf
                    <div class="grid gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Title</label>
                            <input name="title" required class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Category</label>
                            <select id="addCategoryId" name="category_id" required class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                                <option value="">Select category...</option>
                                @foreach(($categories ?? []) as $cat)
                                    <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Subcategory</label>
                            <select id="addSubcategoryId" name="subcategory_id" required class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                                <option value="">Select subcategory...</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">URL (optional)</label>
                            <input name="url" type="url" placeholder="https://..." class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">File (optional)</label>
                            <input name="file" type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx" class="mt-1 w-full text-sm" />
                            <p class="mt-1 text-xs text-gray-500">Accepted: PDF, Word, PowerPoint, Excel (max 25MB). If you upload a file, the URL will be auto-filled.</p>
                        </div>
                    </div>
                    <div class="mt-4 flex items-center justify-end gap-2">
                        <button type="button" id="btnCancelAddMaterial" class="px-3 py-2 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50">Cancel</button>
                        <button type="submit" class="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Material Modal -->
    <div id="editMaterialModal" class="fixed inset-0 bg-black/30 hidden z-50">
        <div class="min-h-full w-full grid place-items-center p-4">
            <div class="bg-white rounded-lg shadow max-w-lg w-full">
                <div class="px-4 py-3 border-b flex items-center justify-between">
                    <h3 class="font-semibold">Edit Material</h3>
                    <button id="btnCloseEditMaterial" class="p-1 hover:bg-gray-100 rounded">
                        <span class="material-symbols-outlined">close</span>
                    </button>
                </div>
                <form id="editMaterialForm" method="POST" action="#" class="p-4" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div class="grid gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Title</label>
                            <input id="editTitle" name="title" required class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Category</label>
                            <select id="editCategoryId" name="category_id" required class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                                @foreach(($categories ?? []) as $cat)
                                    <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Subcategory</label>
                            <select id="editSubcategoryId" name="subcategory_id" required class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                                <option value="">Select subcategory...</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">URL (optional)</label>
                            <input id="editUrl" name="url" type="url" placeholder="https://..." class="mt-1 w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Replace File (optional)</label>
                            <input name="file" type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx" class="mt-1 w-full text-sm" />
                            <p class="mt-1 text-xs text-gray-500">Upload to replace the current file. If provided, URL will be updated to the new file URL.</p>
                        </div>
                    </div>
                    <div class="mt-4 flex items-center justify-end gap-2">
                        <button type="button" id="btnCancelEditMaterial" class="px-3 py-2 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50">Cancel</button>
                        <button type="submit" class="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Global Confirm Modal (reused) -->
    <div id="confirmModal" class="fixed inset-0 bg-black/30 hidden z-[60]">
        <div class="min-h-full w-full grid place-items-center p-4">
            <div class="bg-white rounded-lg shadow max-w-md w-full">
                <div class="px-4 py-3 border-b flex items-center justify-between">
                    <h3 id="confirmTitle" class="font-semibold">Confirm</h3>
                    <button id="confirmClose" class="p-1 hover:bg-gray-100 rounded">
                        <span class="material-symbols-outlined">close</span>
                    </button>
                </div>
                <div class="p-4">
                    <p id="confirmMessage" class="text-gray-700">Are you sure?</p>
                </div>
                <div class="px-4 py-3 border-t flex items-center justify-end gap-2">
                    <button id="confirmCancel" class="px-3 py-2 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50">Cancel</button>
                    <button id="confirmOk" class="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white">Yes, Delete</button>
                </div>
            </div>
        </div>
    </div>

    <script>
    (function(){
        // AJAX search suggestions
        const sInput = document.getElementById('materialSearchInput');
        const sBox = document.getElementById('materialSuggestBox');
        let sTimer = null;
        function hideS(){ sBox?.classList.add('hidden'); if (sBox) sBox.innerHTML=''; }
        function showS(items){
            if (!sBox) return;
            if (!items || items.length === 0){ hideS(); return; }
            sBox.innerHTML = items.map(x=>`<button type="button" class="w-full text-left px-3 py-2 hover:bg-gray-50">${x}</button>`).join('');
            sBox.classList.remove('hidden');
            Array.from(sBox.querySelectorAll('button')).forEach(btn=>{
                btn.addEventListener('click', ()=>{ sInput.value = btn.textContent.trim(); hideS(); });
            });
        }
        sInput?.addEventListener('input', ()=>{
            const q = sInput.value.trim();
            clearTimeout(sTimer);
            if (q.length < 1){ hideS(); return; }
            sTimer = setTimeout(async ()=>{
                try{
                    const url = new URL("{{ route('materials.suggest') }}", window.location.origin);
                    url.searchParams.set('q', q);
                    const res = await fetch(url, {headers:{'X-Requested-With':'XMLHttpRequest'}});
                    const data = await res.json();
                    showS(data);
                }catch(e){ hideS(); }
            }, 180);
        });
        document.addEventListener('click', (e)=>{ if (!sBox?.contains(e.target) && e.target !== sInput){ hideS(); } });

        // Modal helpers
        const addM = document.getElementById('addMaterialModal');
        const editM = document.getElementById('editMaterialModal');
        const btnOpenAdd = document.getElementById('btnOpenAddMaterial');
        const btnCloseAdd = document.getElementById('btnCloseAddMaterial');
        const btnCancelAdd = document.getElementById('btnCancelAddMaterial');
        const btnCloseEdit = document.getElementById('btnCloseEditMaterial');
        const btnCancelEdit = document.getElementById('btnCancelEditMaterial');
        function open(el){ el?.classList.remove('hidden'); }
        function close(el){ el?.classList.add('hidden'); }
        btnOpenAdd?.addEventListener('click', ()=> open(addM));
        btnCloseAdd?.addEventListener('click', ()=> close(addM));
        btnCancelAdd?.addEventListener('click', ()=> close(addM));
        addM?.addEventListener('click', (e)=>{ if(e.target===addM) close(addM); });
        btnCloseEdit?.addEventListener('click', ()=> close(editM));
        btnCancelEdit?.addEventListener('click', ()=> close(editM));
        editM?.addEventListener('click', (e)=>{ if(e.target===editM) close(editM); });

        // Dependent subcategory selects
        async function loadSubs(categoryId, targetSelect, selectedId = null){
            if (!targetSelect) return;
            targetSelect.innerHTML = '<option value="">Loading...</option>';
            try{
                const url = new URL("{{ route('materials.subcategories') }}", window.location.origin);
                url.searchParams.set('category_id', categoryId || '');
                const res = await fetch(url, {headers:{'X-Requested-With':'XMLHttpRequest'}});
                const data = await res.json();
                const options = ['<option value="">Select subcategory...</option>']
                    .concat(data.map(s=>`<option value="${s.id}">${s.name}</option>`));
                targetSelect.innerHTML = options.join('');
                if (selectedId) targetSelect.value = selectedId;
            }catch(e){ targetSelect.innerHTML = '<option value="">Select subcategory...</option>'; }
        }

        const addCat = document.getElementById('addCategoryId');
        const addSub = document.getElementById('addSubcategoryId');
        addCat?.addEventListener('change', ()=> loadSubs(addCat.value, addSub));

        const editCat = document.getElementById('editCategoryId');
        const editSub = document.getElementById('editSubcategoryId');
        editCat?.addEventListener('change', ()=> loadSubs(editCat.value, editSub));

        // Populate edit modal
        const editForm = document.getElementById('editMaterialForm');
        const editTitle = document.getElementById('editTitle');
        const editUrl = document.getElementById('editUrl');
        document.querySelectorAll('.btnEditMaterial').forEach(btn => {
            btn.addEventListener('click', async ()=>{
                const id = btn.getAttribute('data-id');
                const title = btn.getAttribute('data-title');
                const categoryId = btn.getAttribute('data-category-id') || '';
                const subcategoryId = btn.getAttribute('data-subcategory-id') || '';
                const url = btn.getAttribute('data-url') || '';
                editTitle.value = title;
                editUrl.value = url;
                if (editCat) editCat.value = categoryId;
                await loadSubs(categoryId, editSub, subcategoryId);
                editForm.action = `{{ url('materials') }}/${id}`;
                open(editM);
            });
        });

        // Confirm delete modal logic
        const cModal = document.getElementById('confirmModal');
        const cTitle = document.getElementById('confirmTitle');
        const cMsg = document.getElementById('confirmMessage');
        const cOk = document.getElementById('confirmOk');
        const cCancel = document.getElementById('confirmCancel');
        const cClose = document.getElementById('confirmClose');
        let pendingForm = null;
        function openConfirm(title, message, form){ cTitle.textContent = title || 'Confirm'; cMsg.textContent = message || 'Are you sure?'; pendingForm = form; cModal.classList.remove('hidden'); }
        function closeConfirm(){ cModal.classList.add('hidden'); pendingForm = null; }
        cCancel?.addEventListener('click', closeConfirm);
        cClose?.addEventListener('click', closeConfirm);
        cModal?.addEventListener('click', (e)=>{ if(e.target===cModal) closeConfirm(); });
        cOk?.addEventListener('click', ()=>{ if(pendingForm){ pendingForm.submit(); closeConfirm(); } });
        document.querySelectorAll('form.js-confirm-delete').forEach(f => {
            f.addEventListener('submit', (e)=>{ e.preventDefault(); const title = f.getAttribute('data-confirm-title') || 'Confirm'; const msg = f.getAttribute('data-confirm-message') || 'Are you sure?'; openConfirm(title, msg, f); });
        });
    })();
    </script>
</x-admin-layout>
