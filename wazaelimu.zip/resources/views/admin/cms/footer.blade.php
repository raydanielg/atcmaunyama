<x-admin-layout>
    <div class="max-w-4xl mx-auto">
        <h1 class="text-xl font-semibold text-gray-800">CMS — Footer</h1>
        <div class="border-t border-dashed border-gray-300 my-4"></div>
        <p class="text-gray-600 text-sm">Placeholder page for managing footer links and copyright text.</p>
    </div>
</x-admin-layout>
