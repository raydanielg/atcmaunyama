<x-admin-layout>
    <div class="max-w-4xl mx-auto">
        <h1 class="text-xl font-semibold text-gray-800">CMS — Categories</h1>
        <div class="border-t border-dashed border-gray-300 my-4"></div>
        <p class="text-gray-600 text-sm">Placeholder page for mapping landing page categories to learning/materials categories.</p>
    </div>
</x-admin-layout>
