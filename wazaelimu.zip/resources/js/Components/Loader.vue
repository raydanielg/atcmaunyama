<template>
  <div class="loader" role="status" aria-label="Loading"></div>
</template>

<script setup>
// Simple loader component using global .loader CSS in resources/css/app.css
</script>

<style scoped>
/* No extra styles; uses global .loader class */
</style>
